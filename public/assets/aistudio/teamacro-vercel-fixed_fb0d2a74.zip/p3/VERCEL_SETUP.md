# Vercel setup for TEAMACRO (do this once)

## 1. Environment variables
Vercel Dashboard -> TEAMACRO project -> Settings -> Environment Variables.
Tick **Production** (and Preview if you use it) for every variable, then **Redeploy**
(env changes do not apply to old deployments). Variables set in Google AI Studio do NOT carry over.

| Name | Where to get it |
|---|---|
| FIREBASE_PROJECT_ID | `teamacro-a1849` |
| FIREBASE_CLIENT_EMAIL | `client_email` in the service-account JSON |
| FIREBASE_PRIVATE_KEY | `private_key` in the same JSON, pasted whole (BEGIN...END). Literal `\n` is handled. |
| FIREBASE_FIRESTORE_DATABASE_ID | `ai-studio-teamacro-1c75b7f5-7b8e-4f90-9452-2820167e5d5a` |
| FIREBASE_API_KEY | Firebase web API key (Console -> Project settings -> General) |
| SESSION_SECRET | A long random string you generate (e.g. `openssl rand -hex 48`). Required. Never reuse the key. |

Service-account JSON: Firebase Console -> Project settings -> Service accounts -> Generate new private key.
Never commit that file or put it in a VITE_ variable.

## 2. Firebase Console
- Authentication -> Settings -> Authorized domains: add your `*.vercel.app` domain and any custom domain.
- Authentication -> Sign-in method: Email/Password must be enabled.

## 3. Check it
Open `https://YOUR-SITE.vercel.app/api/health`. You should see:
`"config":{"firebaseAdminConfigured":true,"sessionSecretConfigured":true}`.
If either is false, a variable above is missing for the Production scope.

## 4. Tests
`npm run test:vercel`  - replays requests through Vercel's own request helper.
