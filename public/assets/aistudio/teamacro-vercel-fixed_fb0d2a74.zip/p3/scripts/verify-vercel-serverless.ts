/**
 * Regression test for the Vercel deployment.
 * Replays requests through a faithful copy of @vercel/node's request helper
 * (body is pre-read, replayed via PassThrough, exposed on a lazy `req.body`)
 * and exercises the real Express app exactly the way api/index.ts does on Vercel.
 *
 * Run: npx tsx scripts/verify-vercel-serverless.ts
 */
import http from 'node:http';
import { PassThrough } from 'node:stream';

process.env.VERCEL = '1';
process.env.SESSION_SECRET = 'test-only-secret-' + 'x'.repeat(40);
delete process.env.FIREBASE_PRIVATE_KEY;
delete process.env.FIREBASE_CLIENT_EMAIL;
process.env.TEAMACRO_DATA_DIR = '/tmp/teamacro-vercel-test-' + Date.now();

const { default: handler } = await import('../api/index.ts');
const { serverAuthManager } = await import('../src/server/authManager.ts');

let failures = 0;
const check = (name: string, ok: boolean, extra = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${extra ? '  -> ' + extra : ''}`);
  if (!ok) failures++;
};

async function serialize(req: any) { const c: Buffer[] = []; for await (const x of req) c.push(Buffer.from(x)); return Buffer.concat(c); }
function restoreBody(req: any, body: Buffer) {
  const rep = new PassThrough(); const on = rep.on.bind(rep); const originalOn = req.on.bind(req);
  req.read = rep.read.bind(rep);
  req.on = req.addListener = (n: string, cb: any) => (n === 'data' || n === 'end' ? on(n, cb) : originalOn(n, cb));
  rep.write(body); rep.end();
}
function lazy(req: any, prop: string, getter: () => any) {
  const define = (v: any) => Object.defineProperty(req, prop, { value: v, writable: true, configurable: true, enumerable: true });
  Object.defineProperty(req, prop, { configurable: true, enumerable: true, get() { const v = getter(); define(v); return v; }, set(v) { define(v); } });
}
const srv = http.createServer(async (req: any, res: any) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname.startsWith('/api/')) { const q = new URLSearchParams(u.search); q.set('__path', u.pathname.slice(5)); req.url = `/api/index?${q}`; }
  lazy(req, 'query', () => Object.fromEntries(new URL(req.url, 'http://x').searchParams));
  const ct = req.headers['content-type'];
  let body = Buffer.from('');
  if (ct !== undefined) { body = await serialize(req); restoreBody(req, body); }
  lazy(req, 'body', () => (ct?.includes('json') ? (body.length ? JSON.parse(body.toString()) : {}) : body.toString()));
  res.status = (c: number) => { res.statusCode = c; return res; };
  res.json = (o: any) => { res.setHeader('content-type', 'application/json'); res.end(JSON.stringify(o)); };
  handler(req, res);
}).listen(4012);

async function hit(path: string, method = 'GET', body?: any, headers: Record<string, string> = {}, rawBody?: string) {
  const r = await fetch('http://localhost:4012' + path, {
    method, headers: { 'content-type': 'application/json', ...headers },
    body: rawBody ?? (body ? JSON.stringify(body) : undefined),
  });
  const text = await r.text(); let json: any = null; try { json = JSON.parse(text); } catch {}
  return { status: r.status, json, text };
}

// 1. GET works and reports config booleans (no secret values)
let r = await hit('/api/health');
check('GET /api/health returns 200', r.status === 200);
check('health reports firebaseAdminConfigured=false without creds, and leaks no secrets',
  r.json?.config?.firebaseAdminConfigured === false && !r.text.includes('PRIVATE'));

// 2. POST bodies are read (previously: 500 "stream is not readable")
r = await hit('/api/auth/login', 'POST', { identifier: 'nobody@example.com', password: 'wrong-password-1' });
check('POST /api/auth/login is processed (401/400, not 500)', [400, 401, 403].includes(r.status), String(r.status));
r = await hit('/api/auth/login', 'POST', { identifier: '', password: '' });
check('POST login with empty fields -> 400 validation', r.status === 400, String(r.status));
r = await hit('/api/auth/login', 'POST', undefined, {}, '{not json');
check('malformed JSON -> 400 INVALID_JSON, not 500', r.status === 400 && r.json?.error?.code === 'INVALID_JSON', `${r.status} ${r.json?.error?.code}`);

// 3. Unauthenticated / unauthorised cannot create accounts
const payload = { fullName: 'Test Staff', email: `vercel.test.${Date.now()}@example.com`, phone: '08012345678',
  duty: 'Customer Registration Officer', accessCode: 'ACC-123456', password: 'InitPass-123456', role: 'STAFF' };
r = await hit('/api/auth/create-staff', 'POST', payload);
check('create-staff without session -> 401', r.status === 401, String(r.status));
r = await hit('/api/auth/create-staff', 'POST', payload, { Authorization: 'Bearer tmr_s1_forged_deadbeef' });
check('create-staff with forged token -> 401', r.status === 401, String(r.status));

// 4. Forged tokens signed with the OLD hard-coded constant must no longer be accepted
import crypto from 'node:crypto';
const forgedPayload = Buffer.from(JSON.stringify({ u: 'x', e: 'eromoseledavidson68@gmail.com', n: 'x', r: 'LIFETIME_SUPER_ADMIN', rt: 'x', sa: true, mfa: true, sv: 1, iat: Date.now(), exp: Date.now() + 3.6e6 })).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const forgedSig = crypto.createHmac('sha256', 'teamacro-a1849-authoritative-hmac-session-key-v1').update(forgedPayload).digest('hex');
r = await hit('/api/auth/create-staff', 'POST', payload, { Authorization: `Bearer tmr_s1_${forgedPayload}_${forgedSig}` });
check('token forged with the old source-code secret is rejected', r.status === 401, String(r.status));

// 5. Real Super Admin session: request reaches the Firebase step and fails CLEARLY (no fake success)
const accounts: Map<string, any> = (serverAuthManager as any).accounts;
const sa = [...accounts.values()].find((a) => a.isLifetimeSuperAdmin);
if (!sa) { check('seed Lifetime Super Admin exists', false); } else {
  const session = serverAuthManager.createSession(sa, '127.0.0.1', 'test', true);
  r = await hit('/api/auth/create-staff', 'POST', payload, { Authorization: `Bearer ${session.token}` });
  check('Super Admin create-staff does NOT fabricate success when Firebase Admin creds are missing',
    r.status === 503 && r.json?.success === false, `${r.status} ${r.json?.message?.slice(0, 120)}`);
  check('error names the missing Vercel variables (names only)',
    /FIREBASE_CLIENT_EMAIL/.test(r.text) && /FIREBASE_PRIVATE_KEY/.test(r.text));
  check('no account left behind after the failed creation', !serverAuthManager.findAccountByIdentifier(payload.email));

  // Admin / Staff sessions cannot create privileged accounts
  for (const role of ['ADMIN', 'STAFF'] as const) {
    const fake = { ...sa, id: `t_${role}`, role, isLifetimeSuperAdmin: false };
    const s = serverAuthManager.createSession(fake, '127.0.0.1', 'test', true);
    const rr = await hit('/api/auth/create-staff', 'POST', payload, { Authorization: `Bearer ${s.token}` });
    check(`${role} session cannot create staff -> 403`, rr.status === 403, String(rr.status));
    const ra = await hit('/api/super-admin/create-admin', 'POST', { ...payload, role: 'ADMIN' }, { Authorization: `Bearer ${s.token}` });
    check(`${role} session cannot create admin -> 403/401`, [401, 403].includes(ra.status), String(ra.status));
  }

  // 6. MFA challenge survives a different serverless instance
  const challenge = serverAuthManager.initiateMfaChallenge(sa);
  (serverAuthManager as any).mfaChallenges.clear(); // simulate another instance with empty memory
  const v = serverAuthManager.verifyMfaCode(challenge.tempToken, '000000', '127.0.0.1', 'test');
  check('MFA challenge verifies on a fresh instance (fails only on the wrong code, not "expired or invalid")',
    v.success === false && !/expired or invalid/i.test(v.error || ''), v.error);
  const bad = serverAuthManager.verifyMfaCode(challenge.tempToken.slice(0, -4) + 'beef', '000000', '127.0.0.1', 'test');
  check('tampered MFA challenge is rejected', bad.success === false && /expired or invalid/i.test(bad.error || ''), bad.error);
}

srv.close();
console.log(failures ? `\n${failures} check(s) FAILED` : '\nAll Vercel serverless checks passed.');
process.exit(failures ? 1 : 0);
