import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Fetches a list and keeps the screen stable.
 * - Never wipes existing data during refetch.
 * - Only updates state when data actually changed.
 * - Treats a single empty/failed response as suspect (needs `emptyConfirmations` in a row).
 * - Pauses polling while the tab is hidden; never overlaps requests.
 */
export function useStableList(fetcher, { pollMs = 0, emptyConfirmations = 2, getKey = (x) => x.id } = {}) {
  const [items, setItems] = useState([]);
  const [initialLoading, setInitialLoading] = useState(true);
  const [error, setError] = useState(null);

  const lastJson = useRef("[]");
  const emptyStreak = useRef(0);
  const inFlight = useRef(false);
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  const refresh = useCallback(async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    try {
      const next = await fetcherRef.current();
      if (!Array.isArray(next)) throw new Error("Expected an array");

      if (next.length === 0 && lastJson.current !== "[]") {
        emptyStreak.current += 1;
        if (emptyStreak.current < emptyConfirmations) return; // ignore one-off empty blip
      } else {
        emptyStreak.current = 0;
      }

      const sorted = [...next].sort((a, b) => String(getKey(a)).localeCompare(String(getKey(b))));
      const json = JSON.stringify(sorted);
      if (json !== lastJson.current) {
        lastJson.current = json;
        setItems(sorted);
      }
      setError(null);
    } catch (e) {
      setError(e); // keep old items on screen
    } finally {
      inFlight.current = false;
      setInitialLoading(false);
    }
  }, [emptyConfirmations, getKey]);

  useEffect(() => {
    refresh();
    if (!pollMs) return;
    const id = setInterval(() => {
      if (document.visibilityState === "visible") refresh();
    }, pollMs);
    const onVisible = () => document.visibilityState === "visible" && refresh();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [refresh, pollMs]);

  return { items, initialLoading, error, refresh };
}
