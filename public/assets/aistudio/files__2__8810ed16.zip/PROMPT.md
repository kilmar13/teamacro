# Prompt (paste into Claude Code / Cursor / your AI coding tool)

I have a layout-flicker bug in my admin dashboard (staff management page). Screen recording findings:

- The staff table ("Personnel Details / Assigned Position & Tier / Dedicated Route / Programme / Status / Administrative Actions") keeps flipping between 1 row (only "Davidson Eromosele") and 2 rows (plus "Okon Mcuthur" with Edit/Permissions/Suspend/Delete/Inspect buttons).
- Each flip resizes the columns, re-wraps header text, and shoves the "Issued Backend Access Authorizations & Codes" cards below up and down.

Likely causes: (a) the list state is cleared or replaced with partial data during refetch/polling, (b) the table uses auto column layout so widths recompute on every row change, (c) unstable React keys or new array/object identities on every poll cause full re-renders.

Do this:

1. Find every place in the codebase that renders a table or list from fetched data (search for `<table`, `.map(` over fetched arrays, `setInterval`, `useEffect` fetches, `refetchInterval`, `setX([])` before a fetch, `router.refresh()` in intervals).
2. Create ONE shared hook `useStableList` (file provided) and ONE shared `DataTable` component + CSS (files provided). Do not duplicate logic per page.
3. Migrate the staff table AND the "Issued Backend Access Authorizations & Codes" card grid first, then every other list/table you found.
4. Rules the fix must follow:
   - Never clear existing data while a refetch is in flight; show a skeleton only on the very first load.
   - Only replace state when the new data actually differs (deep compare), so identical polls cause zero re-render.
   - Treat a sudden empty or errored response as suspect: keep the old list and accept "empty" only after 2 consecutive empty responses.
   - Pause polling when the tab is hidden; no overlapping requests.
   - Tables use `table-layout: fixed` with explicit column widths and a reserved min-height.
   - Use stable keys (database id, never array index or random values).
5. Check the API/route that returns the staff list: confirm it doesn't intermittently return partial results (pagination, caching, serverless cold starts, a flaky filter). Fix it if it does.
6. Add a lint rule or a short note in CONTRIBUTING/README: "All lists must use useStableList + DataTable."
7. When done, list every file you changed and every place you migrated.
