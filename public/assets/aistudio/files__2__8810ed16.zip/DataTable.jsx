import "./data-table.css";

/**
 * columns: [{ key, header, width: "24%", align?: "right", render?: (row) => node }]
 * Fixed layout + reserved height = no column resizing or page jumping.
 */
export default function DataTable({ columns, rows, rowKey = (r) => r.id, loading, minRows = 2, empty = "No records" }) {
  return (
    <div className="dt-wrap" style={{ "--dt-min-rows": minRows }}>
      <table className="dt">
        <colgroup>
          {columns.map((c) => (
            <col key={c.key} style={{ width: c.width }} />
          ))}
        </colgroup>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} style={{ textAlign: c.align }}>{c.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {loading ? (
            Array.from({ length: minRows }).map((_, i) => (
              <tr key={`sk-${i}`} className="dt-skeleton">
                {columns.map((c) => (
                  <td key={c.key}><span className="dt-bar" /></td>
                ))}
              </tr>
            ))
          ) : rows.length === 0 ? (
            <tr><td colSpan={columns.length} className="dt-empty">{empty}</td></tr>
          ) : (
            rows.map((row) => (
              <tr key={rowKey(row)}>
                {columns.map((c) => (
                  <td key={c.key} style={{ textAlign: c.align }}>
                    {c.render ? c.render(row) : row[c.key]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
