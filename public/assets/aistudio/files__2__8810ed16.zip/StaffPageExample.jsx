import DataTable from "./DataTable";
import { useStableList } from "./useStableList";

const columns = [
  { key: "person",    header: "Personnel Details",        width: "24%", render: (r) => (<><b>{r.name}</b><div>{r.email}</div></>) },
  { key: "position",  header: "Assigned Position & Tier", width: "18%", render: (r) => r.position },
  { key: "route",     header: "Dedicated Route",          width: "14%", render: (r) => r.route },
  { key: "programme", header: "Programme / Responsibility", width: "22%", render: (r) => r.programme },
  { key: "status",    header: "Status",                   width: "8%",  render: (r) => r.status },
  { key: "actions",   header: "Administrative Actions",   width: "14%", align: "right", render: (r) => r.actions },
];

export default function StaffPage() {
  const { items, initialLoading } = useStableList(
    () => fetch("/api/staff", { cache: "no-store" }).then((r) => { if (!r.ok) throw new Error(r.status); return r.json(); }),
    { pollMs: 30000 }
  );
  return <DataTable columns={columns} rows={items} loading={initialLoading} minRows={2} />;
}
